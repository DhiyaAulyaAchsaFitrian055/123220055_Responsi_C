/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.buku;
import connect.connect;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Lab Informatika
 */
public class DAOBuku implements interfaceDAOBuku{

    @Override
    public void create(modelbuku sewa_buku) {
         try{
             String query = "INSERT INTO sewa_buku (id, nama_penyewa, judul_buku, jenis_buku, nomor_telepon, durasi_sewa, total_biaya) VALUE(?,?,?,?,?,?,?);"; 
             modelbuku dm = new modelbuku();
             PreparedStatement statement;
             statement = connect.connection().prepareStatement(query);
             statement.setInt(1, sewa_buku.getid());
              statement.setString(2, sewa_buku.getnama_penyewa());
              statement.setString(3, sewa_buku.getjudul_buku());
              statement.setString(4, sewa_buku.getjenis_buku());
              statement.setString(5, sewa_buku.getnomor_telepon());
              statement.setInt(6, sewa_buku.getdurasi_sewa());
              statement.setInt(7, sewa_buku.gettotal_biaya());
              statement.executeUpdate();
              statement.close();
         }catch (SQLException e){
             System.out.println("Input Failed: " + e.getLocalizedMessage());
         }
    }

    @Override
    public void update(modelbuku buku) {
        
    }

    @Override
    public void delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<modelbuku> getAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean hapusData(String id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
