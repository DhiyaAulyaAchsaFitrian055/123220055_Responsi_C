/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.buku;
import java.util.List;

/**
 *
 * @author Lab Informatika
 */
public interface interfaceDAOBuku {
 public void create(modelbuku buku);
 public void update(modelbuku buku);
 public void delete (int id);
 public List<modelbuku>getAll();
 public boolean hapusData(String id);
}
